import { TestBed } from '@angular/core/testing';

import { ScheduleTrainService } from './schedule-train.service';

describe('ScheduleTrainService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ScheduleTrainService = TestBed.get(ScheduleTrainService);
    expect(service).toBeTruthy();
  });
});
