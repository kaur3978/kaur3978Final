import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TraincomponentComponent } from './traincomponent.component';

describe('TraincomponentComponent', () => {
  let component: TraincomponentComponent;
  let fixture: ComponentFixture<TraincomponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TraincomponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TraincomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
