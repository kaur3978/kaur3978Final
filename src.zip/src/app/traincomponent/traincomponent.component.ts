import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-traincomponent',
  templateUrl: './traincomponent.component.html',
  styleUrls: ['./traincomponent.component.css']
})
export class TraincomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
